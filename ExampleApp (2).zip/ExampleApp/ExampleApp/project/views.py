# Create your views here.
from django.shortcuts import render_to_response, redirect
from project.models import User
from django.template.context import RequestContext
import json
from django.template import loader
from django.http import HttpResponse
from project.forms import UserForm, LoginForm
from time import sleep
from project import settings

def json_render(template, data, request):
    t = loader.get_template(template)
    c = RequestContext(request)
    c.update(data)
    return HttpResponse(json.dumps({
        'action': 'render',
        'data': t.render(c)
    }), mimetype="application/javascript")

def json_ok(msg, request):
    return HttpResponse(json.dumps({
        'action': 'ok',
        'data': msg
    }), mimetype="application/javascript")

def json_error(msg, request):
    return HttpResponse(json.dumps({
        'action': 'error',
        'data': msg
    }), mimetype="application/javascript")

def json_redirect(url, request):
    return HttpResponse(json.dumps({
        'action': 'redirect',
        'data': url
    }), mimetype="application/javascript")

def home(request):
    users = User.objects.all()
    return render_to_response('home.html', {
        'users': users
    }, context_instance=RequestContext(request))
    
def create(request):
    sleep(settings.DELAY)
    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            form.save()
            return json_ok("User created", request)
    else:
        form = UserForm()
        
    return json_render('form.html', {
        'form': form,
        'action': '/create/'
    }, request)
    
def edit(request, id):
    sleep(settings.DELAY)
    try:
        user = User.objects.get(id=id)
    except User.DoesNotExist:
        return json_error("User doesn't exist", request)
        
    if request.method == 'POST':
        form = UserForm(request.POST, instance=user)
        if form.is_valid():
            form.save()
            return json_ok("User edited", request)
    else:
        form = UserForm(instance=user)
        
    return json_render('form.html', {
        'form': form,
        'action': '/edit/%s/'%user.id
    }, request)

def delete(request, id):
    sleep(settings.DELAY)
    if request.session.get('user_id') == id: 
        return json_error("Cannot delete yourself", request)
    
    try:
        user = User.objects.get(id=id)
    except User.DoesNotExist:
        return json_error("User doesn't exist", request)
    
    user.delete()
    return json_ok("User deleted", request)

def login(request):
    msg = ''
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            try:
                user = User.objects.get(login=form.cleaned_data['login'], password=form.cleaned_data['password'])
                request.session['user'] = '%s %s (%s)' % (user.first_name, user.last_name, user.login) 
                request.session['user_id'] = user.id 
                request.session.save()
                return redirect('/')
            except:
                msg = 'Invalid login or password'
    else:
        form = LoginForm()
        
    return render_to_response('login.html', {
        'form': form,
        'msg': msg
    }, context_instance=RequestContext(request))
    
def logout(request):
    del request.session['user']
    request.session.save()
    return redirect('/')

    