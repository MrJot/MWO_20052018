from django.db import models

class User(models.Model):
    class Meta:
        db_table = 'user'
        ordering = ['last_name', 'first_name']
        
    first_name = models.CharField('First name', max_length=100)
    last_name = models.CharField('Last name', max_length=100)
    login = models.CharField('Login', max_length=30, unique=True)
    password = models.CharField('Password', max_length=100)
    email = models.EmailField('E-mail', max_length=100, unique=True)
    
    
    
    