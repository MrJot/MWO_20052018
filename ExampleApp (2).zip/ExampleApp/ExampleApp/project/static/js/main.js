function message(p) {
	var d = $('<div id="message" title="'+p.title+'"><p><img class="msgicon" src="/static/icons/'+p.icon+'.png" alt="'+p.icon+'" />'+p.text+'</p></div>');
    var dict = {
        autoOpen: true,
        resizable: false,
        height:220,
        modal: true,
        buttons: {
            "OK": function() {
			    $('#message').dialog('close');
			    if(p.success)
			    	p.success()
        	}
        },
        close: function(e, ui) {
    	    $('#message').remove();
        }
    }
    $('body').append(d);
    d.dialog(dict);
}

function error(text) {
    message({
    	text: text, 
    	title: 'Error', 
    	icon: 'critical'
    });
}

function info(text, success) {
    message({
    	text: text, 
    	title: 'Info', 
    	icon: 'info',
    	success: success
    });
}


function user_create() {
	
	var d = $('<div id="user-dialog" title="Create user"></div>');
	
	var dict = {
        autoOpen: true,
        resizable: true,
        height: 100,
        width: 200,
        modal: true,
        position: 'center',
        close: function(e, ui) {
    	    $('#user-dialog').remove();
        }
    }
    
    $('body').append(d);
    d.dialog(dict);
    
    $.ajax({
		url: '/create/',
		dataType: 'json',
		type: "GET",
		cache: false,
		async: true,
		success: function(json) {
			$('#user-dialog').html(json.data);
			
			var d = $('#user-dialog');
			d.dialog("option", "height", "auto");
			d.dialog("option", "width", "auto");
			d.dialog("option", "position", "center");
		},
		error: function(request,e) {
			if (request.status == 0) {
				alert('Cannot connect to host');
			} else {
				alert('Loading error');
			}
		}
	});
}

function user_close(){
	$('#user-dialog').dialog("close");
}

function user_save() {
	var inputs = $('#user-dialog input').serialize();
	
	$.ajax({
		url: $('#user-form').attr('action'),
		dataType: 'json',
		type: "POST",
		data: inputs,
		cache: false,
		async: true,
		success: function(json) {
			if (json.action == 'render') {
				$('#user-dialog').html(json.data);
				
				var d = $('#user-dialog');
				d.dialog("option", "height", "auto");
				d.dialog("option", "width", "auto");
				d.dialog("option", "position", "center");
			} else if(json.action == 'ok') {
				info(json.data, function(){ document.location.reload(true); });
				$('#user-dialog').dialog("close");
			} else {
				error(json.data);
				$('#user-dialog').dialog("close");
			}
		},
		error: function(request,e) {
			if (request.status == 0) {
				alert('Cannot connect to host');
			} else {
				alert('Loading error');
			}
		}
	});
}

function user_delete(id) {
	$.ajax({
		url: '/delete/'+id+'/',
		dataType: 'json',
		type: "GET",
		cache: false,
		async: true,
		success: function(json) {
			if (json.action == 'redirect') {
				
			} else if(json.action == 'ok') {
				info(json.data, function(){ document.location.reload(true); });
			} else {
				error(json.data);
			}
		},
		error: function(request,e) {
			if (request.status == 0) {
				alert('Cannot connect to host');
			} else {
				alert('Loading error');
			}
		}
	});
}

function user_edit(id) {
	
	var d = $('<div id="user-dialog" title="Edit user"></div>');
	
	var dict = {
        autoOpen: true,
        resizable: true,
        height: 150,
        width: 200,
        modal: true,
        position: 'center',
        close: function(e, ui) {
    	    $('#user-dialog').remove();
        }
    }
    
    $('body').append(d);
    d.dialog(dict);
    
    $.ajax({
		url: '/edit/'+id+'/',
		dataType: 'json',
		type: "GET",
		cache: false,
		async: true,
		success: function(json) {
			$('#user-dialog').html(json.data);
			
			var d = $('#user-dialog');
			d.dialog("option", "height", "auto");
			d.dialog("option", "width", "auto");
			d.dialog("option", "position", "center");
		},
		error: function(request,e) {
			if (request.status == 0) {
				alert('Cannot connect to host');
			} else {
				alert('Loading error');
			}
		}
	});
}
