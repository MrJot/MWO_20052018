# -*- coding: utf-8 -*-
from django import forms
from project.models import User

class UserForm(forms.ModelForm):
    class Meta:
        model = User
        exclude = ('permission','superadmin','key','download','upload','stay', 'company')
        
    password = forms.CharField(min_length=8, max_length=20, required=True, widget=forms.PasswordInput())
    
    def __init__(self, *args, **kwargs):
        forms.ModelForm.__init__(self, *args, **kwargs)
        if self.instance.id:
            # blokowanie możliwości zmiany hasła
            del self.fields['password']
    
class LoginForm(forms.Form):
    login = forms.CharField(required=True, max_length=30)
    password = forms.CharField(required=True, max_length=100, widget=forms.PasswordInput())
    