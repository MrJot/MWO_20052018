from django.conf.urls import patterns, include, url
from project import settings

# Uncomment the next two lines to enable the admin:
# from django.contrib import admin
# admin.autodiscover()

urlpatterns = patterns('',
    # Examples:
    url(r'^$', 'project.views.home', name='home'),
    url(r'^create/$', 'project.views.create', name='create'),
    url(r'^edit/(?P<id>\d+)/$', 'project.views.edit', name='edit'),
    url(r'^delete/(?P<id>\d+)/$', 'project.views.delete', name='delete'),
    url(r'^login/$', 'project.views.login', name='login'),
    url(r'^logout/$', 'project.views.logout', name='logout'),
    # url(r'^project/', include('project.foo.urls')),

    # Uncomment the admin/doc line below to enable admin documentation:
    # url(r'^admin/doc/', include('django.contrib.admindocs.urls')),

    # Uncomment the next line to enable the admin:
    # url(r'^admin/', include(admin.site.urls)),
    url(r'^static/(?P<path>.*)$', 'django.views.static.serve', {
        'document_root': settings.MEDIA_ROOT,
    }),
)
